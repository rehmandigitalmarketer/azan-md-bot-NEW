const express = require('express');
const path = require('path');
const pairHandler = require('./pair');

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'public')));

app.post('/api/pair', (req, res) => {
    pairHandler(req, res);
});

app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
    console.log(`\n🚀 AZAN MD Vercel Portal Running at: http://localhost:${PORT}\n`);
});
