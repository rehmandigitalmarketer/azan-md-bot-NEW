const { default: makeWASocket, useMultiFileAuthState, fetchLatestBaileysVersion, Browsers, delay } = require('@whiskeysockets/baileys');
const P = require('pino');
const fs = require('fs-extra');
const path = require('path');
const os = require('os');

module.exports = async (req, res) => {
    // Enable CORS
    res.setHeader('Access-Control-Allow-Credentials', true);
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET,OPTIONS,PATCH,DELETE,POST,PUT');
    res.setHeader('Access-Control-Allow-Headers', 'X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version');

    if (req.method === 'OPTIONS') {
        res.status(200).end();
        return;
    }

    if (req.method !== 'POST') {
        return res.status(405).json({ success: false, error: 'Method Not Allowed. Use POST.' });
    }

    try {
        let { number } = req.body || {};
        if (!number) {
            return res.status(400).json({ success: false, error: 'Please enter a valid WhatsApp number.' });
        }

        const cleanNumber = String(number).replace(/\D/g, '');
        if (!cleanNumber || cleanNumber.length < 10 || cleanNumber.length > 15) {
            return res.status(400).json({ success: false, error: 'Invalid WhatsApp number length. Please include your country code (e.g. 923363006367).' });
        }

        // Temporary unique session dir in Vercel /tmp
        const tempAuthDir = path.join(os.tmpdir(), `auth_${cleanNumber}_${Date.now()}`);
        await fs.ensureDir(tempAuthDir);

        const { version } = await fetchLatestBaileysVersion();
        const { state, saveCreds } = await useMultiFileAuthState(tempAuthDir);

        const sock = makeWASocket({
            version,
            auth: state,
            printQRInTerminal: false,
            logger: P({ level: 'fatal' }),
            browser: Browsers.ubuntu('Chrome'),
            connectTimeoutMs: 30000,
            defaultQueryTimeoutMs: 30000
        });

        sock.ev.on('creds.update', saveCreds);

        // Wait a small delay before requesting pairing code
        await delay(3000);

        let code = await sock.requestPairingCode(cleanNumber);
        code = code?.match(/.{1,4}/g)?.join('-') || code;

        // Clean up temp dir in background after 30 seconds
        setTimeout(() => {
            try {
                sock.end();
                fs.removeSync(tempAuthDir);
            } catch (e) {}
        }, 30000);

        return res.status(200).json({
            success: true,
            code: code,
            number: cleanNumber,
            expiresIn: 120
        });

    } catch (error) {
        console.error('Pairing Serverless Error:', error);
        return res.status(500).json({
            success: false,
            error: error.message || 'Failed to generate WhatsApp pairing code. Please try again.'
        });
    }
};
